package com.glvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.glvc.bean.Subject;

import com.glvc.dbutil.DbUtil;

public class SubjectDAO {
	public int insert(Subject S) throws ClassNotFoundException, SQLException
	{
		Connection con=DbUtil.dbConn();
		if(con!=null)
		{
			System.out.println("connection established");
			
		}
		else
		{
			System.out.println("connection not established");
		}
		
		String sql="insert into Subject values(?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,S.getSubid());
		ps.setString(2,S.getSubname());
		
		return ps.executeUpdate();
	}
	public List<Subject> display() throws ClassNotFoundException, SQLException{
		Connection con=DbUtil.dbConn();
		if(con!=null) {
			System.out.println("connection with dB is established ");
		}
		else {
			System.out.println("connection failed ");
		}
		List<Subject> list=new ArrayList<Subject>();
		String sql="select * from Subject";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			Subject s=new Subject();
			s.setSubid(rs.getInt(1));
			s.setSubname(rs.getString(2));
			
			
			list.add(s);
		}
		return list;
}
	
	public int edit(Subject S) throws SQLException, ClassNotFoundException
	{
		Connection con=DbUtil.dbConn();
		if (con!=null)
		{
			System.out.println("connection establised");
		}
		else
		{
			System.out.println("connection not established");
		}
	
	String sql="Update Subject set subname=? where subid=? ";
	PreparedStatement ps=con.prepareStatement(sql);
	
	ps.setInt(2, S.getSubid());
	
	ps.setString(1, S.getSubname());
	return ps.executeUpdate();
	
	
	}
	public int delete(Subject S) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.dbConn();
		if(con!=null) {
			System.out.println("connection with dB is established ");
		}
		else {
			System.out.println("connection failed ");
		}
		String sql="delete from subject where subid=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,S.getSubid());
		
		
		return ps.executeUpdate();
	}
	

}